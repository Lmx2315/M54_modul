#ifndef DMA_PORT_CH_MISC_H
#define DMA_PORT_CH_MISC_H

#include "dma_port_ch_reg_fields.hpp"

/// Quantity elements for structure DMA_PORT_CH_RegInfo
///@def TOTAL_CNT_REGS_DMA_PORT_CH_
#define TOTAL_CNT_REGS_DMA_PORT_CH_  4



#endif
