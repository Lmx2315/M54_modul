﻿/*
 * Created by SharpDevelop.
 * User: Lmx2315
 * Date: 08/08/2018
 * Time: 13:53
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace fft_writer
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.TextBox my_port_box;
		private System.Windows.Forms.Button Btn_start;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Label Test_l1;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.Button save_botton;
		private System.Windows.Forms.TextBox Console1;
		private System.Windows.Forms.TextBox text_fsemple;
		private System.Windows.Forms.Label Lab_Ft;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox text_N_fft;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btn_Norm;
		private System.Windows.Forms.ComboBox cmbWindow;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.my_port_box = new System.Windows.Forms.TextBox();
            this.Btn_start = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Test_l1 = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.save_botton = new System.Windows.Forms.Button();
            this.Console1 = new System.Windows.Forms.TextBox();
            this.text_fsemple = new System.Windows.Forms.TextBox();
            this.Lab_Ft = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.text_N_fft = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_Norm = new System.Windows.Forms.Button();
            this.cmbWindow = new System.Windows.Forms.ComboBox();
            this.my_ip_box = new System.Windows.Forms.TextBox();
            this.dut_ip = new System.Windows.Forms.TextBox();
            this.dut_port = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.channal_box = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.open_file_BTN = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox_sch = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // my_port_box
            // 
            this.my_port_box.Location = new System.Drawing.Point(286, 59);
            this.my_port_box.Name = "my_port_box";
            this.my_port_box.Size = new System.Drawing.Size(75, 21);
            this.my_port_box.TabIndex = 0;
            this.my_port_box.Text = "8888";
            // 
            // Btn_start
            // 
            this.Btn_start.Location = new System.Drawing.Point(286, 172);
            this.Btn_start.Name = "Btn_start";
            this.Btn_start.Size = new System.Drawing.Size(75, 23);
            this.Btn_start.TabIndex = 1;
            this.Btn_start.Text = "listen";
            this.Btn_start.UseVisualStyleBackColor = true;
            this.Btn_start.Click += new System.EventHandler(this.Button1Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 25;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Test_l1
            // 
            this.Test_l1.Location = new System.Drawing.Point(12, 59);
            this.Test_l1.Name = "Test_l1";
            this.Test_l1.Size = new System.Drawing.Size(100, 23);
            this.Test_l1.TabIndex = 5;
            this.Test_l1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // save_botton
            // 
            this.save_botton.Location = new System.Drawing.Point(286, 255);
            this.save_botton.Name = "save_botton";
            this.save_botton.Size = new System.Drawing.Size(75, 23);
            this.save_botton.TabIndex = 6;
            this.save_botton.Text = "save";
            this.save_botton.UseVisualStyleBackColor = true;
            this.save_botton.Click += new System.EventHandler(this.Save_bottonClick);
            // 
            // Console1
            // 
            this.Console1.Location = new System.Drawing.Point(15, 537);
            this.Console1.Multiline = true;
            this.Console1.Name = "Console1";
            this.Console1.Size = new System.Drawing.Size(339, 187);
            this.Console1.TabIndex = 7;
            // 
            // text_fsemple
            // 
            this.text_fsemple.Location = new System.Drawing.Point(12, 62);
            this.text_fsemple.Name = "text_fsemple";
            this.text_fsemple.Size = new System.Drawing.Size(100, 21);
            this.text_fsemple.TabIndex = 8;
            this.text_fsemple.Text = "12";
            this.text_fsemple.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.text_fsemple.TextChanged += new System.EventHandler(this.TextBox1TextChanged);
            // 
            // Lab_Ft
            // 
            this.Lab_Ft.Location = new System.Drawing.Point(118, 62);
            this.Lab_Ft.Name = "Lab_Ft";
            this.Lab_Ft.Size = new System.Drawing.Size(59, 23);
            this.Lab_Ft.TabIndex = 9;
            this.Lab_Ft.Text = "Ft(Mhz)";
            this.Lab_Ft.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(118, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 23);
            this.label1.TabIndex = 12;
            this.label1.Text = "N (FFT)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // text_N_fft
            // 
            this.text_N_fft.Location = new System.Drawing.Point(12, 101);
            this.text_N_fft.Name = "text_N_fft";
            this.text_N_fft.Size = new System.Drawing.Size(100, 21);
            this.text_N_fft.TabIndex = 11;
            this.text_N_fft.Text = "2048";
            this.text_N_fft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.text_N_fft.TextChanged += new System.EventHandler(this.N_fftTextChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(12, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 10;
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_Norm
            // 
            this.btn_Norm.Location = new System.Drawing.Point(22, 155);
            this.btn_Norm.Name = "btn_Norm";
            this.btn_Norm.Size = new System.Drawing.Size(75, 23);
            this.btn_Norm.TabIndex = 13;
            this.btn_Norm.Text = "норм/Абс";
            this.btn_Norm.UseVisualStyleBackColor = true;
            this.btn_Norm.Click += new System.EventHandler(this.Btn_NormClick);
            // 
            // cmbWindow
            // 
            this.cmbWindow.FormattingEnabled = true;
            this.cmbWindow.Location = new System.Drawing.Point(12, 128);
            this.cmbWindow.Name = "cmbWindow";
            this.cmbWindow.Size = new System.Drawing.Size(100, 21);
            this.cmbWindow.TabIndex = 14;
            this.cmbWindow.SelectedIndexChanged += new System.EventHandler(this.cmbWindow_SelectedIndexChanged);
            // 
            // my_ip_box
            // 
            this.my_ip_box.Location = new System.Drawing.Point(286, 23);
            this.my_ip_box.Name = "my_ip_box";
            this.my_ip_box.Size = new System.Drawing.Size(75, 21);
            this.my_ip_box.TabIndex = 15;
            this.my_ip_box.Text = "127.0.0.1";
            // 
            // dut_ip
            // 
            this.dut_ip.Location = new System.Drawing.Point(286, 99);
            this.dut_ip.Name = "dut_ip";
            this.dut_ip.Size = new System.Drawing.Size(75, 21);
            this.dut_ip.TabIndex = 16;
            this.dut_ip.Text = "127.0.0.1";
            // 
            // dut_port
            // 
            this.dut_port.Location = new System.Drawing.Point(286, 137);
            this.dut_port.Name = "dut_port";
            this.dut_port.Size = new System.Drawing.Size(75, 21);
            this.dut_port.TabIndex = 17;
            this.dut_port.Text = "666";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(244, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "my_IP";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(244, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "dut_IP";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(244, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "port";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(234, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "dut_port";
            // 
            // channal_box
            // 
            this.channal_box.Location = new System.Drawing.Point(22, 28);
            this.channal_box.Name = "channal_box";
            this.channal_box.Size = new System.Drawing.Size(75, 21);
            this.channal_box.TabIndex = 22;
            this.channal_box.Text = "1";
            this.channal_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "channal";
            // 
            // open_file_BTN
            // 
            this.open_file_BTN.Location = new System.Drawing.Point(286, 284);
            this.open_file_BTN.Name = "open_file_BTN";
            this.open_file_BTN.Size = new System.Drawing.Size(75, 23);
            this.open_file_BTN.TabIndex = 0;
            this.open_file_BTN.Text = "open_file";
            this.open_file_BTN.UseVisualStyleBackColor = true;
            this.open_file_BTN.Click += new System.EventHandler(this.Open_file_BTN_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.Timer2_Tick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(22, 196);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "filtr";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(22, 225);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 25;
            this.button2.Text = "filtr2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // textBox_sch
            // 
            this.textBox_sch.Location = new System.Drawing.Point(286, 210);
            this.textBox_sch.Name = "textBox_sch";
            this.textBox_sch.Size = new System.Drawing.Size(75, 21);
            this.textBox_sch.TabIndex = 26;
            this.textBox_sch.Text = "1";
            this.textBox_sch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 337);
            this.Controls.Add(this.textBox_sch);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.open_file_BTN);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.channal_box);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dut_port);
            this.Controls.Add(this.dut_ip);
            this.Controls.Add(this.my_ip_box);
            this.Controls.Add(this.cmbWindow);
            this.Controls.Add(this.btn_Norm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.text_N_fft);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Lab_Ft);
            this.Controls.Add(this.text_fsemple);
            this.Controls.Add(this.Console1);
            this.Controls.Add(this.save_botton);
            this.Controls.Add(this.Test_l1);
            this.Controls.Add(this.Btn_start);
            this.Controls.Add(this.my_port_box);
            this.Name = "MainForm";
            this.Text = "fft_writer";
            this.Load += new System.EventHandler(this.MainFormLoad);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

        private System.Windows.Forms.TextBox my_ip_box;
        private System.Windows.Forms.TextBox dut_ip;
        private System.Windows.Forms.TextBox dut_port;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox channal_box;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button open_file_BTN;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox_sch;
    }
}
