﻿/*
 * Created by SharpDevelop.
 * User: Lmx2315
 * Date: 08/08/2018
 * Time: 13:53
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Text;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using PlotWrapper;
using DSPLib;
using System.Numerics;
using System.Net;
using System.Net.Sockets;
using System.Threading;
//using FFTLibrary;


namespace fft_writer
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
        delegate void ShowMessageMethod(string msg);

        public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			Debug.WriteLine("Debug Information-Product Starting ");
			Debug.WriteLine("------------------------ ");

		}
        //----------ETH------------
        UdpClient _server = null;
        IPEndPoint _client = null;
        Thread _listenThread = null;
        private bool _isServerStarted = false;

        Class1 rcv_func=new Class1();
		Form1 fft_form     = new Form1();
		
		static int  BUF_N=8192;
		static int Fsample=12;

		Byte  [] RCV         =new byte[64000];
		int   [] FFT_array   =new int [8192];
	    int   [] packet_data =new int [8192];
        int[] packet_data_i = new int [8192];
        int[] packet_data_q = new int [8192];
        Byte  [] rcv_BUF     =new byte[32768];
  
		int flag_NEW_FFT;
        byte[] buf = new byte[64];

        int sch_packet = 0;
        int FLAG_filtr = 0;

        string fileName;
        string text_from_file;

         Plot fig1 = new Plot("I Input", "Sample", "Вольт","","","","","");
	     Plot fig2 = new Plot("Q Input", "Sample", "Вольт","","","","","");
		 Plot fig3 = new Plot("FFT (dBV)", "кГц", "Mag (dBV)","","","","","");
     

        //-------------------eth-------------------------
        private void Start()
        {
            IPAddress my_ip;
            UInt16 my_port;

            my_ip = IPAddress.Parse(my_ip_box.Text);
            my_port = UInt16.Parse(my_port_box.Text);

            //Create the server.
               IPEndPoint serverEnd = new IPEndPoint(my_ip, my_port);           
            // IPEndPoint serverEnd = new IPEndPoint(IPAddress.Any, 1234);

            _server = new UdpClient(serverEnd);
            _server.Client.ReceiveBufferSize = 8192 * 200;//увеличиваем размер приёмного буфера!!!
            Debug.WriteLine("Waiting for a client...");
            //Create the client end.
            //_client = new IPEndPoint(IPAddress.Any, 0);
           
            //Start listening.
            Thread listenThread = new Thread(new ThreadStart(Listening));
            listenThread.Start();
            //Change state to indicate the server starts.
            _isServerStarted = true;

            //-----шлём приветствие программсе на си--------------
            UdpClient client = new UdpClient();
            client.Connect("127.0.0.1", 666);

            string msg = "Hello bro!!!\n";
            byte[] data = Encoding.UTF8.GetBytes(msg);
            int number_bytes = client.Send(data, data.Length);
            client.Close();
        }

        private void Stop()
        {
            try
            {
                //Stop listening.
                _listenThread.Join();
                Debug.WriteLine("Server stops.");
                _server.Close();
                //Changet state to indicate the server stops.
                _isServerStarted = false;
            }
            catch (Exception excp)
            { }
        }

        int FLAG_UDP_RCV = 0;

        private void Listening()
        {
            byte[] data;
            //Listening loop.
            while (true)
            {
                //receieve a message form a client.
                data = _server.Receive(ref _client);
                if(FLAG_UDP_RCV==0)
                {
                    //  receivedMsg = Encoding.ASCII.GetString(data, 0, data.Length);
                    Array.Copy(data, RCV, data.Length);//копируем массив отсчётов в форму обработки                    
                      FLAG_UDP_RCV = 1;
                }
                sch_packet++;
            }
        }
         
        byte [] BUFFER_1 = new byte[64000];
        byte [] BUFFER_2 = new byte[64000];

        void MSG_collector()
        {

           if (RCV[3] == 1) Array.Copy(RCV, BUFFER_1, BUF_N*4);//копируем массив отсчётов в форму обработки 
           if (RCV[3] == 2) Array.Copy(RCV, BUFFER_2, BUF_N*4);//

            if (Convert.ToByte(channal_box.Text) == 1) { BUF_convert(BUFFER_1, BUF_N*4); }
            if (Convert.ToByte(channal_box.Text) == 2) { BUF_convert(BUFFER_2, BUF_N*4); }

            work1();

            if (flag_NEW_FFT == 1)
            {
                fft_out();
                flag_NEW_FFT = 0;
            }
        }

        private void ShowMsg(string msg)
        {
            this.Console1.Text += msg + "\r\n";
        }
        //-----------------------------------------------

        void Timer1Tick ()
        {

        }

        Byte sch =0;

        Byte[] cos_gen ()
        {
            Byte[] data = new byte[1446];

            int i = 0;
            int n = 0;
            double z = 0;
            int x = 0;

            if (sch < 254) sch++; else sch = 0;

            i = 6;

            data[0] = 0;
            data[1] = 1;
            data[2] = 0;
            data[3] = 0;
            data[4] = 0;
            data[5] = sch;

            for (n=0;n<360;n++)
            {
                z = 30000 * Math.Cos(2 * Math.PI * i / 20);
                x = Convert.ToInt16(z);
             //   Debug.WriteLine("x:" + x);
                data[i  ] = Convert.ToByte((x >> 8) & 0xff);
                data[i+1] = Convert.ToByte((x >> 0) & 0xff);
        
                z = 30000 * Math.Cos(2 * Math.PI * i / 20);
                x = Convert.ToInt16(z);

                data[i+2] = Convert.ToByte((x >> 8) & 0xff);
                data[i+3] = Convert.ToByte((x >> 0) & 0xff);
    
                i = i + 4;
            }

            return data;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            if (FLAG_UDP_RCV==1)
            {
                MSG_collector();
                FLAG_UDP_RCV = 0;
            }            

            textBox_sch.Text = Convert.ToString(sch_packet);

            sch_packet = 0;
        }

    
		void MainFormLoad(object sender, EventArgs e)
		{
			//fft_form.Show(this);
			BUF_N =Convert.ToInt16(text_N_fft.Text);
			// Load window combo box with the Window Names (from ENUMS)
            cmbWindow.DataSource = Enum.GetNames(typeof(DSPLib.DSP.Window.Type));			
		}

        // Calculate log(number) in the indicated log base.
        private double LogBase(double number, double log_base)
        {
            return Math.Log(number) / Math.Log(log_base);
        }

        int post_U_i=0;
        int post_U_q=0;

        

        void fft_out ()
		{

            UInt32 zeros = Convert.ToUInt32(0);
            uint N_temp;
            int N_complex;
            int i;
            int N;
            uint z;

            N_temp    = Convert.ToUInt32(BUF_N);
            N_complex = Convert.ToInt32 (BUF_N);

            double A_max = 0;
            double B_max = 0;
            double C_max = 0;

            double[] m_sort = new double[BUF_N];
            double[] m_sort2 = new double[BUF_N];

            double[] fft_array = new double[BUF_N];
            double[] fft_array_x = new double[BUF_N];
            double[] fft_array_y = new double[BUF_N];

            double[] t = new double[BUF_N];
            double[] A = new double[BUF_N];

            string selectedWindowName = cmbWindow.SelectedValue.ToString();

            DSPLib.DSP.Window.Type windowToApply = (DSPLib.DSP.Window.Type)Enum.Parse(typeof(DSPLib.DSP.Window.Type), selectedWindowName);

            for (i = 0; i < N_temp; i++)
            {
                //fft_array_x[i] = Convert.ToDouble(packet_data_i[i]- rcv_func.mat_oj_i); //удаляем постояннуюу составляющую высчитанную ранее
                //fft_array_y[i] = Convert.ToDouble(packet_data_q[i]- rcv_func.mat_oj_q);

                if (packet_data_i[i] > 32767)
                {
                    z = (uint)(packet_data_i[i]);
                    z = (~z) & 0xffff;
                    packet_data_i[i] = -1 * Convert.ToInt32(z + 1);
                }
                else packet_data_i[i] = Convert.ToInt32(packet_data_i[i]);

                if (packet_data_q[i] > 32767)
                {
                    z = (uint)(packet_data_q[i]);
                    z = (~z) & 0xffff;
                    packet_data_q[i] = -1 * Convert.ToInt32(z + 1);
                }
                else packet_data_q[i] = Convert.ToInt32(packet_data_q[i]);

                fft_array_x[i] = Convert.ToDouble(packet_data_i[i]- post_U_i); //
                fft_array_y[i] = Convert.ToDouble(packet_data_q[i]- post_U_q);

            }

            // Apply window to the time series data
            double[] wc = DSP.Window.Coefficients(windowToApply, N_temp);
            double windowScaleFactor = DSP.Window.ScaleFactor.Signal(wc);

            double[] windowedTimeSeries_i = DSP.Math.Multiply(fft_array_x, wc);
            double[] windowedTimeSeries_q = DSP.Math.Multiply(fft_array_y, wc);

            //  Plot Time Series data
      //      fig1.PlotData(windowedTimeSeries_q);
      //      fig1.Show();

            //  Plot Time Series data
       //     fig2.PlotData(windowedTimeSeries_i);
       //     fig2.Show();

            // Instantiate & Initialize the FFT class
            DSPLib.FFT fft = new DSPLib.FFT();
            fft.Initialize(2 * N_temp, zeros);

            // Start a Stopwatch
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            // Perform a DFT
            // System.Numerics.Complex[] cpxResult = fft.Execute(windowedTimeSeries);

            FFTLibrary.Complex fft_z = new FFTLibrary.Complex();

            int k = Convert.ToInt16(LogBase(N_temp, 2));

            fft_z.FFT(1, k, windowedTimeSeries_i, windowedTimeSeries_q);

            System.Numerics.Complex[] cpxResult = new System.Numerics.Complex[N_complex];

            for (i = 0; i < N_complex; i++)
            {
                cpxResult[i] = new System.Numerics.Complex(windowedTimeSeries_i[i], windowedTimeSeries_q[i]);
            }

            // Convert the complex result to a scalar magnitude 
            double[] magResult = DSP.ConvertComplex.ToMagnitude(cpxResult);
            magResult = DSP.Math.Multiply(magResult, 1);

            // Plot the DFT Magnitude
            // fig2.PlotData(magResult);
            // fig2.Show();

            // Calculate the frequency span
            double[] fSpan = fft.FrequencySpan(2 * Fsample);

            // Convert and Plot Log Magnitude
            double[] mag = DSP.ConvertComplex.ToMagnitude(cpxResult);
            mag = DSP.Math.Multiply(mag, 1);
            double[] magLog = DSP.ConvertMagnitude.ToMagnitudeDBV(mag);
            int j;

            for (j = 0; j < magLog.Length; j++) if (magLog[j] < 0) magLog[j] = 0;

            for (j = 0; j < N_temp; j++)
            {
			//	 A[j] = magLog[j];
                if (j < ( N_temp / 2))      A[j] = magLog[j + (N_temp / 2)];
                if (j > ((N_temp / 2) - 1)) A[j] = magLog[j - (N_temp / 2)];
                  t[j] = -3121+(6250*j/(N_temp));//важно сначала умножить а потом поделить!!!! атоноль
				// Debug.WriteLine("t[]:"+t[j]);
            }

            for (j = 0; j < N_temp; j++)
            {
                magLog[j] = A[N_temp - 1 - j];
            }

            if (FLAG_filtr == 1) vid_filtr(magLog);
            if (FLAG_filtr == 2)
            {
                 
                vid_filtr (magLog);
                vid2_filtr(magLog);
                vid3_filtr(magLog);
                vid4_filtr(magLog);
            }

            int k_max = 0;
            double m1x,m1y;
            double m2x,m2y;
            double m3x,m3y;
            
            Array.Copy(magLog, m_sort,  BUF_N);
            Array.Copy(magLog, m_sort2, BUF_N);
            Array.Sort(m_sort);

            (k_max,A_max) = MAX_f(magLog, BUF_N);       //определяем Х координату первого максимума
            m1x = t[k_max];
            m1y = A_max;

            if (k_max>10 && k_max< (BUF_N-20))   for (i=0;i<20;i++) m_sort2[k_max + i-10] = 0;

            (k_max,B_max) = MAX_f(m_sort2, BUF_N);      //определяем Х координату второго максимума
            m2x = t[k_max];
            m2y = B_max;                                //определяем второй максимум
           
            if (k_max > 10 && k_max < (BUF_N - 20)) for (i = 0; i < 20; i++) m_sort2[k_max + i - 10] = 0;

            (k_max,C_max) = MAX_f(m_sort2, BUF_N); 
    
            m3y =  C_max;
            m3x =  t[k_max];;

          //  magLog[0] = 80;//выравниваю шкалу
            fig3.PlotData(t,magLog, A_max, B_max,C_max,m1x,m1y,m2x,m2y,m3x,m3y);
            fig3.Show();
        }

        double[] Z0 = new double[BUF_N];
        double[] Z1 = new double[BUF_N];
        double[] Z2 = new double[BUF_N];
        double[] Z3 = new double[BUF_N];
        double[] Z4 = new double[BUF_N];
        double[] Z5 = new double[BUF_N];
        double[] Z6 = new double[BUF_N];
        double[] Z7 = new double[BUF_N];
        double[] Z8 = new double[BUF_N];
        double[] Z9 = new double[BUF_N];

        double[] Z_end = new double[BUF_N];

        void vid_filtr(double[] a)
        {
            int i = 0;

            for (i = 0; i < BUF_N; i++)
            {
                Z9[i] = Z8[i];
                Z8[i] = Z7[i];
                Z7[i] = Z6[i];
                Z6[i] = Z5[i];
                Z5[i] = Z4[i];
                Z4[i] = Z3[i];
                Z3[i] = Z2[i];
                Z2[i] = Z1[i];
                Z1[i] = Z0[i];
                Z0[i] = a[i];

                a[i] = (a[i] + Z0[i] + Z1[i] + Z2[i] + Z3[i] + Z4[i] + Z5[i] + Z6[i] + Z7[i] + Z8[i] + Z9[i]) / 11;

            }
        }
        //---------------------
        double[] x0 = new double[BUF_N];
        double[] x1 = new double[BUF_N];
        double[] x2 = new double[BUF_N];
        double[] x3 = new double[BUF_N];
        double[] x4 = new double[BUF_N];
        double[] x5 = new double[BUF_N];
        double[] x6 = new double[BUF_N];
        double[] x7 = new double[BUF_N];
        double[] x8 = new double[BUF_N];
        double[] x9 = new double[BUF_N];

        double[] x10 = new double[BUF_N];
        double[] x11 = new double[BUF_N];
        double[] x12 = new double[BUF_N];
        double[] x13 = new double[BUF_N];
        double[] x14 = new double[BUF_N];
        double[] x15 = new double[BUF_N];
        double[] x16 = new double[BUF_N];
        double[] x17 = new double[BUF_N];
        double[] x18 = new double[BUF_N];
        double[] x19 = new double[BUF_N];

        double[] x_end = new double[BUF_N];

        void vid2_filtr(double[] a)
        {
            int i = 0;

            for (i = 0; i < BUF_N; i++)
            {
                x19[i] = x18[i];
                x18[i] = x17[i];
                x17[i] = x16[i];
                x16[i] = x15[i];
                x15[i] = x14[i];
                x14[i] = x13[i];
                x13[i] = x12[i];
                x12[i] = x11[i];
                x11[i] = x10[i];
                x10[i] = x9[i];

                x9[i] = x8[i];
                x8[i] = x7[i];
                x7[i] = x6[i];
                x6[i] = x5[i];
                x5[i] = x4[i];
                x4[i] = x3[i];
                x3[i] = x2[i];
                x2[i] = x1[i];
                x1[i] = x0[i];
                x0[i] = a[i];

                a[i] = (a[i] + x0[i] + x1[i] + x2[i] + x3[i] + x4[i] + x5[i] + x6[i] + x7[i] + x8[i] + x9[i] + x10[i] +x11[i] + x12[i] +x13[i]+x14[i]+x15[i]+x16[i]+x17[i]+x18[i]+x19[i]) / 21;

            }
        }

        double[] c0 = new double[BUF_N];
        double[] c1 = new double[BUF_N];
        double[] c2 = new double[BUF_N];
        double[] c3 = new double[BUF_N];
        double[] c4 = new double[BUF_N];
        double[] c5 = new double[BUF_N];
        double[] c6 = new double[BUF_N];
        double[] c7 = new double[BUF_N];
        double[] c8 = new double[BUF_N];
        double[] c9 = new double[BUF_N];

        double[] c10 = new double[BUF_N];
        double[] c11 = new double[BUF_N];
        double[] c12 = new double[BUF_N];
        double[] c13 = new double[BUF_N];
        double[] c14 = new double[BUF_N];
        double[] c15 = new double[BUF_N];
        double[] c16 = new double[BUF_N];
        double[] c17 = new double[BUF_N];
        double[] c18 = new double[BUF_N];
        double[] c19 = new double[BUF_N];

        double[] c_end = new double[BUF_N];

        void vid3_filtr(double[] a)
        {
            int i = 0;

            //if (sch_filtr!=10) sch_filtr++; else

            for (i = 0; i < BUF_N; i++)
            {
                c19[i] = c18[i];
                c18[i] = c17[i];
                c17[i] = c16[i];
                c16[i] = c15[i];
                c15[i] = c14[i];
                c14[i] = c13[i];
                c13[i] = c12[i];
                c12[i] = c11[i];
                c11[i] = c10[i];
                c10[i] = c9[i];

                c9[i] = c8[i];
                c8[i] = c7[i];
                c7[i] = c6[i];
                c6[i] = c5[i];
                c5[i] = c4[i];
                c4[i] = c3[i];
                c3[i] = c2[i];
                c2[i] = c1[i];
                c1[i] = c0[i];
                c0[i] = a[i];

                a[i] = (a[i] + c0[i] + c1[i] + c2[i] + c3[i] + c4[i] + c5[i] + c6[i] + c7[i] + c8[i] + c9[i] + c10[i] + c11[i] + c12[i] + c13[i] + c14[i] + c15[i] + c16[i] + c17[i] + c18[i] + c19[i]) / 21;

            }
        }
        //---------------------
        double[] v0 = new double[BUF_N];
        double[] v1 = new double[BUF_N];
        double[] v2 = new double[BUF_N];
        double[] v3 = new double[BUF_N];
        double[] v4 = new double[BUF_N];
        double[] v5 = new double[BUF_N];
        double[] v6 = new double[BUF_N];
        double[] v7 = new double[BUF_N];
        double[] v8 = new double[BUF_N];
        double[] v9 = new double[BUF_N];

        double[] v10 = new double[BUF_N];
        double[] v11 = new double[BUF_N];
        double[] v12 = new double[BUF_N];
        double[] v13 = new double[BUF_N];
        double[] v14 = new double[BUF_N];
        double[] v15 = new double[BUF_N];
        double[] v16 = new double[BUF_N];
        double[] v17 = new double[BUF_N];
        double[] v18 = new double[BUF_N];
        double[] v19 = new double[BUF_N];

        double[] v_end = new double[BUF_N];

        void vid4_filtr(double[] a)
        {
            int i = 0;

            //if (sch_filtr!=10) sch_filtr++; else

            for (i = 0; i < BUF_N; i++)
            {
                v19[i] = v18[i];
                v18[i] = v17[i];
                v17[i] = v16[i];
                v16[i] = v15[i];
                v15[i] = v14[i];
                v14[i] = v13[i];
                v13[i] = v12[i];
                v12[i] = v11[i];
                v11[i] = v10[i];
                v10[i] = v9[i];

                v9[i] = v8[i];
                v8[i] = v7[i];
                v7[i] = v6[i];
                v6[i] = v5[i];
                v5[i] = v4[i];
                v4[i] = v3[i];
                v3[i] = v2[i];
                v2[i] = v1[i];
                v1[i] = v0[i];
                v0[i] = a[i];

                a[i] = (a[i] + v0[i] + v1[i] + v2[i] + v3[i] + v4[i] + v5[i] + v6[i] + v7[i] + v8[i] + v9[i] + v10[i] + v11[i] + v12[i] + v13[i] + v14[i] + v15[i] + v16[i] + v17[i] + v18[i] + v19[i]) / 21;

            }
        }
//-------------------------------------
        void SerialPort1DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
		{
		
		}

        (int n ,double Amax ) MAX_f (double [] m,int N)
        {
            int i = 0;
            double max = 0;
            int k = 0;

            for (i=0;i<N;i++)
            {
                if (max<m[i])
                {
                    max = m[i];
                    k = i;
                }
            }
            return (k,max);
        }

		void Button1Click(object sender, EventArgs e)
		{

            if (_isServerStarted)
            {
                Stop();
                Btn_start.Text = "StartServer";
            }
            else
            {
                Start();
                Btn_start.Text = "StopServer";
            }

        }
		void Port_enClick(object sender, EventArgs e)
		{
           
			
		}
		void Save_bottonClick(object sender, EventArgs e)
		{ 
   			saveFileDialog1.Filter = "text|*.txt|data|*.dat|fir coef|*.coff";  
   			saveFileDialog1.Title = "Save an File";  
   			
		 if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
            return;
        	// получаем выбранный файл
        	string filename = saveFileDialog1.FileName;
        	// сохраняем текст в файл
        	System.IO.File.WriteAllText(filename, Console1.Text);
        	MessageBox.Show("Файл сохранен");
		    
		}


		void array_save (int [] a,int N)
		{
			string text="";
		
			System.IO.StreamWriter textFile = new System.IO.StreamWriter(@"c:\temp\c_sharp_test.txt");
			Debug.WriteLine("сохраняем сформированый массив в файл");
			
			for (int i = 0; i < N; i++)
		            {
						text=text+Convert.ToString(a[i])+"\r\n";
		            }
			textFile.WriteLine(text);
	          
			textFile.Close();
		}
	
		void N_fftTextChanged(object sender, EventArgs e)
		{
            int n = 0;
            n= Convert.ToInt16(text_N_fft.Text);

            if ((n==64)||(n==128)||(n==256)||(n==512)||(n==1024)||(n==2048)||(n==4096))   BUF_N =Convert.ToInt16(text_N_fft.Text);
			//Debug.WriteLine("изменили BUF_N:"+BUF_N);
		}
		void TextBox1TextChanged(object sender, EventArgs e)
		{
			Fsample=Convert.ToInt16(text_fsemple);
			//Debug.WriteLine("изменили BUF_N:"+BUF_N);
		}
		void Btn_NormClick(object sender, EventArgs e)
		{
			if (btn_Norm.Text=="норм/Абс") btn_Norm.Text="Абс/норм"; else btn_Norm.Text="норм/Абс";
		}

        private void cmbWindow_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Open_file_BTN_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                fileName = openFileDialog1.FileName;
                text_from_file = File.ReadAllText(fileName);
   
            }
        }

        int[] data_0_i = new int[BUF_N];
        int[] data_0_q = new int[BUF_N];

        int BUF_convert(byte [] m, int col)
        {
            int i = 0;
            int k = 0;
            int l = 0;

            for (i = 4; i < col; i++)//
            {             
                    if (k == 0) data_0_q[l] = Convert.ToInt32(m[i])<<8;
                    if (k == 1) data_0_q[l] = data_0_q[l] + Convert.ToInt32(m[i]);
         
                    if (k == 2) data_0_i[l] = Convert.ToInt32(m[i]) << 8;
                    if (k == 3) data_0_i[l] = data_0_i[l] + Convert.ToInt32(m[i]);

                if (k != 3) k = k + 1;
                else
                {
                  k = 0;
                  l = l + 1;
                }
            }
            return 1;
        }

        void work1()
        {
            Array.Copy(data_0_i, packet_data_i, BUF_N);//копируем массив отсчётов в форму обработки	
            Array.Copy(data_0_q, packet_data_q, BUF_N);//копируем массив отсчётов в форму обработки	

            flag_NEW_FFT = 1;//сообщаем форме что пришёл новый массив fft
        }


        //-----------------------------------
        private void Timer2_Tick(object sender, EventArgs e)
        {
         }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (FLAG_filtr == 1) FLAG_filtr = 0; else FLAG_filtr = 1;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (FLAG_filtr == 2) FLAG_filtr = 0; else FLAG_filtr = 2;
        }
    }
}
