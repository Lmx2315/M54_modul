#ifndef GPIO_H
#define GPIO_H

void Init_Periphs(void);

#endif
